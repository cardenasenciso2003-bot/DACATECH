const K=['dt_cl','dt_ca','dt_nv'];
export async function onRequestGet({env}){const o={};if(!env.DATA)return Response.json(o);
  for(const k of K){const v=await env.DATA.get(k);if(v)o[k]=JSON.parse(v)}return Response.json(o)}
export async function onRequestPut({request,env}){const k=new URL(request.url).searchParams.get('k');
  if(!env.DATA||!K.includes(k))return new Response('no',{status:400});
  await env.DATA.put(k,JSON.stringify(await request.json()));return Response.json({ok:true})}
