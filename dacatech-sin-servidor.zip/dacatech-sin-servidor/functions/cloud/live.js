import {provider,out} from './_lib.js';
export async function onRequestGet({request,env}){
  try{const u=new URL(request.url),p=provider(u.searchParams.get('p'),env);
    if(!p)return out({error:'Plataforma no soportada'},400);
    return out({url:await p.live(u.searchParams.get('serial'),parseInt(u.searchParams.get('ch'))||1)})
  }catch(e){return out({error:e.message})}}
