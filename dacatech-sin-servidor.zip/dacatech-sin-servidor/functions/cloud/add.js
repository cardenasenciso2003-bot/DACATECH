import {provider,out} from './_lib.js';
export async function onRequestPost({request,env}){
  try{const b=await request.json(),p=provider(b.p,env);
    if(!p)return out({ok:false,error:'Plataforma no soportada. Usa EZVIZ o Imou/Dahua.'},400);
    if(!b.serial||!b.code)return out({ok:false,error:'Falta serial o código'},400);
    await p.add(String(b.serial).trim(),String(b.code).trim());return out({ok:true})
  }catch(e){return out({ok:false,error:e.message})}}
