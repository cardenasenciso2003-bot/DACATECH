// Conexión por nube con serial + código de verificación (EZVIZ e Imou/Dahua)
const FORM={'Content-Type':'application/x-www-form-urlencoded'},JS={'Content-Type':'application/json'};
const J=async(u,o)=>(await fetch(u,o)).json();
const form=o=>new URLSearchParams(o).toString();
const md5=async s=>[...new Uint8Array(await crypto.subtle.digest('MD5',new TextEncoder().encode(s)))].map(b=>b.toString(16).padStart(2,'0')).join('');
const cache={};
async function tok(k,fn){const c=cache[k];if(c&&c.exp>Date.now())return c.t;const r=await fn();cache[k]={t:r.t,exp:Date.now()+r.ttl};return r.t}

const ezviz=env=>({
  async token(){return tok('ez',async()=>{
    if(!env.EZVIZ_KEY)throw new Error('Falta configurar EZVIZ_KEY y EZVIZ_SECRET');
    const j=await J('https://open.ys7.com/api/lapp/token/get',{method:'POST',headers:FORM,body:form({appKey:env.EZVIZ_KEY,appSecret:env.EZVIZ_SECRET})});
    if(j.code!='200')throw new Error('EZVIZ: '+j.msg);return{t:j.data.accessToken,ttl:5*864e5}})},
  async add(s,c){const j=await J('https://open.ys7.com/api/lapp/device/add',{method:'POST',headers:FORM,body:form({accessToken:await this.token(),deviceSerial:s,validateCode:c})});
    if(j.code!='200'&&j.code!='20017')throw new Error('EZVIZ: '+j.msg+' ('+j.code+')')},
  async live(s,ch){const j=await J('https://open.ys7.com/api/lapp/v2/live/address/get',{method:'POST',headers:FORM,body:form({accessToken:await this.token(),deviceSerial:s,channelNo:ch,protocol:2,quality:1})});
    if(j.code!='200')throw new Error('EZVIZ: '+j.msg+' ('+j.code+')');return j.data.url}
});

const imou=env=>({
  async sys(){const time=Math.floor(Date.now()/1000),nonce=crypto.randomUUID();
    return{ver:'1.0',appId:env.IMOU_ID,sign:await md5(`time:${time},nonce:${nonce},appSecret:${env.IMOU_SECRET}`),time,nonce}},
  async call(m,p){if(!env.IMOU_ID)throw new Error('Falta configurar IMOU_ID y IMOU_SECRET');
    const j=await J('https://openapi.easy4ip.com/openapi/'+m,{method:'POST',headers:JS,body:JSON.stringify({system:await this.sys(),id:crypto.randomUUID(),params:p})});
    const r=j.result||{};if(r.code!='0'){const e=new Error('Imou: '+(r.msg||r.code));e.code=r.code;throw e}return r.data||{}},
  async token(){return tok('im',async()=>{const d=await this.call('accessToken',{});return{t:d.accessToken,ttl:Math.max(60,(d.expireTime||3600)-300)*1000}})},
  async add(s,c){try{await this.call('bindDevice',{token:await this.token(),deviceId:s,code:c})}catch(e){if(!/DV1001|DV1003|exist|bound/i.test(e.code+e.message))throw e}},
  async live(s,ch){const token=await this.token(),p={token,deviceId:s,channelId:String(ch-1)};let d;
    try{d=await this.call('bindDeviceLive',{...p,streamId:1})}catch(e){d=await this.call('getLiveStreamInfo',p)}
    const st=(d.streams||[]).find(x=>x.hls);if(!st)throw new Error('Imou: el equipo no entregó video HLS');return st.hls}
});
export const provider=(name,env)=>({ezviz,imou}[name]||(()=>null))(env);
export const out=(o,c=200)=>new Response(JSON.stringify(o),{status:c,headers:JS});
